package ContactService;

import java.util.HashMap;
import java.util.Map;

public class ContactService {
    private Map<String, Contact> contactList;

    public ContactService() {
        this.contactList = new HashMap<>();
    }

    public void addContact(Contact contact) {
    	
        // Verify that the contact ID is not already in use
        if (contactList.containsKey(contact.getContactId())) {
            throw new IllegalArgumentException("Contact ID " + contact.getContactId() + " is already in use.");
        }

        // Add the contact to the map
        contactList.put(contact.getContactId(), contact);
    }

    public void deleteContact(String contactId) {
    	
        // Check if the contact ID exists
        if (!contactList.containsKey(contactId)) {
            throw new IllegalArgumentException("Contact with ID " + contactId + " does not exist.");
        }

        // Remove the contact from the map
        contactList.remove(contactId);
    }

    public void updateContact(String contactId, String firstName, String lastName, String phoneNumber, String address) {
    	
        // Check if the contact ID exists
        if (!contactList.containsKey(contactId)) {
            throw new IllegalArgumentException("Contact with ID " + contactId + " does not exist.");
        }

        // Get the existing contact
        Contact existingContact = contactList.get(contactId);

        // Update the contact fields
        existingContact.setFirstName(firstName);
        existingContact.setLastName(lastName);
        existingContact.setPhoneNumber(phoneNumber);
        existingContact.setAddress(address);
    }
    
    public void updateContactFirstName(String contactId, String firstName) {
    	
        // Check if the contact ID exists
        if (!contactList.containsKey(contactId)) {
            throw new IllegalArgumentException("Contact with ID " + contactId + " not found");
        }

        // Get the existing contact
        Contact existingContact = contactList.get(contactId);

        // Update the first name
        existingContact.setFirstName(firstName);
    }

    public void updateContactLastName(String contactId, String lastName) {
    	
        // Check if the contact ID exists
        if (!contactList.containsKey(contactId)) {
            throw new IllegalArgumentException("Contact with ID " + contactId + " not found.");
        }

        // Get the existing contact
        Contact existingContact = contactList.get(contactId);

        // Update the last name
        existingContact.setLastName(lastName);
    }

    public void updateContactPhoneNumber(String contactId, String phone) {
    	
        // Check if the contact ID exists
        if (!contactList.containsKey(contactId)) {
            throw new IllegalArgumentException("Contact with ID " + contactId + " not found.");
        }

        // Get the existing contact
        Contact existingContact = contactList.get(contactId);

        // Update the phone
        existingContact.setPhoneNumber(phone);
    }

    public void updateContactAddress(String contactId, String address) {
    	
        // Check if the contact ID exists
        if (!contactList.containsKey(contactId)) {
            throw new IllegalArgumentException("Contact with ID " + contactId + " not found.");
        }

        // Get the existing contact
        Contact existingContact = contactList.get(contactId);

        // Update the address
        existingContact.setAddress(address);
    }
    
    public Contact getContact(String contactId) {
    	
    	// Check if the contact ID exists
    	if (!contactList.containsKey(contactId)) {
    		throw new IllegalArgumentException("Contact with ID " + contactId + " not found.");
    	}
    	
    	// Return the contact
    	return contactList.get(contactId);
    }
}
