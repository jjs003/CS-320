package ContactService;

public class Contact {
	private final String TOO_BIG_OR_NULL = "must be 10 characters or less and cannot be null.";
	private final String ALREADY_INITIALIZED = "Contact ID is already initialized and cannot be modified.";
	private final String BAD_PHONE_NUMBER = "Phone number must be exactly 10 numbers long.";
	
	// Contact ID string, must be 10 characters or shorter
	private String contactId;
	
	// First name, must be 10 characters or shorter
	private String firstName;
	
	// Last name, must be 10 characters or shorter
	private String lastName;
	
	// Phone number, must be exactly 10 digits long
	private String phoneNumber;
	
	// Address, must be 30 characters or shorter
	private String address;
	
	// Constructor
	public Contact(String Id, String firstName, String lastName, String phoneNumber, String address) {
		setContactId(Id);
		setFirstName(firstName);
		setLastName(lastName);
		setPhoneNumber(phoneNumber);
		setAddress(address);
	}
	
	// Contact ID getter
	public String getContactId() {
		return contactId;
	}
	
	// Contact ID setter, cannot be updated once set
	public void setContactId(String contactId) {
        if (this.contactId != null) {
            throw new IllegalStateException(ALREADY_INITIALIZED);
        }
        if (contactId == null || contactId.length() > 10) {
            throw new IllegalArgumentException("Contact ID " + TOO_BIG_OR_NULL);
        }
        this.contactId = contactId;
    }
	
	// Getter for the first name
    public String getFirstName() {
        return firstName;
    }

    // Setter for the first name
    public void setFirstName(String firstName) {
        if (firstName == null || firstName.length() > 10) {
            throw new IllegalArgumentException("First name" + TOO_BIG_OR_NULL);
        }
        this.firstName = firstName;
    }

    // Getter for the last name
    public String getLastName() {
        return lastName;
    }

    // Setter for the last name
    public void setLastName(String lastName) {
        if (lastName == null || lastName.length() > 10) {
            throw new IllegalArgumentException("Last name " + TOO_BIG_OR_NULL);
        }
        this.lastName = lastName;
    }

    // Getter for the phone number
    public String getPhoneNumber() {
        return phoneNumber;
    }

    // Setter for the phone number
    public void setPhoneNumber(String phoneNumber) {
        if (phoneNumber == null || phoneNumber.length() != 10 || !phoneNumber.matches("\\d+")) {
            throw new IllegalArgumentException(BAD_PHONE_NUMBER);
        }
        this.phoneNumber = phoneNumber;
    }

    // Getter for the address
    public String getAddress() {
        return address;
    }

    // Setter for the address
    public void setAddress(String address) {
        if (address == null || address.length() > 30) {
            throw new IllegalArgumentException("Address " + TOO_BIG_OR_NULL);
        }
        this.address = address;
    }
}