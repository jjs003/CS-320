package test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.BeforeEach;

import ContactService.Contact;
import ContactService.ContactService;

class ContactServiceTest {
	
	private ContactService contactList;
	
	@BeforeEach
	void setUp() {
		contactList = new ContactService();
	}

	@Test
	void testAddContact() {
		Contact contact = new Contact("1234567891", "Maryjobeth", "Cooperhand", "4174346472", "454 S Island Ln, Pensacola, FL");
		contactList.addContact(contact);
		assertEquals(contact, contactList.getContact("1234567891"));
	}
	
	@Test
	void testAddContactWithDuplicateId() {
		Contact contact1 = new Contact("1234567891", "Maryjobeth", "Cooperhand", "4174346472", "454 S Island Ln, Pensacola, FL");
		Contact contact2 = new Contact("1234567891", "John", "Smith", "4173568976", "324 N Rock St, Pensacola, FL");
		
		contactList.addContact(contact1);
		
		assertThrows(IllegalArgumentException.class, () -> contactList.addContact(contact2));
	}
	
	@Test
	void testDeleteContact() {
		Contact contact = new Contact("1234567891", "Maryjobeth", "Cooperhand", "4174346472", "454 S Island Ln, Pensacola, FL");
		contactList.addContact(contact);
		contactList.deleteContact("1234567891");
		assertThrows(IllegalArgumentException.class, () -> contactList.getContact("1234567891"));
	}
	
	@Test
	void testDeleteNonExistingContact() {
		assertThrows(IllegalArgumentException.class, () -> contactList.deleteContact("noID"));
	}
	
	@Test
	void testUpdateContact() {
		Contact contact = new Contact("1234567891", "Maryjobeth", "Cooperhand", "4174346472", "454 S Island Ln, Pensacola, FL");
		contactList.addContact(contact);
		
		contactList.updateContact("1234567891", "John", "Smith", "4173568976", "324 N Rock St, Pensacola, FL");
		
		Contact updatedContact = contactList.getContact("1234567891");
		
		assertEquals("John", updatedContact.getFirstName());
		assertEquals("Smith", updatedContact.getLastName());
		assertEquals("4173568976", updatedContact.getPhoneNumber());
		assertEquals("324 N Rock St, Pensacola, FL", updatedContact.getAddress());		
	}
	
	@Test
	void testUpdateNonExistingContact() {
		assertThrows(IllegalArgumentException.class, () -> contactList.updateContact("noID", "John", "Smith", "4173568976", "324 N Rock St, Pensacola, FL"));
	}
	
	@Test
	void testUpdateContactFirstName() {
		Contact contact = new Contact("1234567891", "Maryjobeth", "Cooperhand", "4174346472", "454 S Island Ln, Pensacola, FL");
		contactList.addContact(contact);
		
		contactList.updateContactFirstName("1234567891", "John");
		
		Contact updatedContact = contactList.getContact("1234567891");
		
		assertEquals("John", updatedContact.getFirstName());
	}
	
	@Test
	void testUpdateContactFirstNameNonExistingContact() {
		assertThrows(IllegalArgumentException.class, () -> contactList.updateContactFirstName("noID", "John"));
	}
	
	@Test
	void testUpdateContactLastName() {
		Contact contact = new Contact("1234567891", "Maryjobeth", "Cooperhand", "4174346472", "454 S Island Ln, Pensacola, FL");
		contactList.addContact(contact);
		
		contactList.updateContactLastName("1234567891", "Smith");
		
		Contact updatedContact = contactList.getContact("1234567891");
		
		assertEquals("Smith", updatedContact.getLastName());
	}
	
	@Test
	void testUpdateContactLastNameNonExistingContact() {
		assertThrows(IllegalArgumentException.class, () -> contactList.updateContactLastName("noID", "Smith"));
	}
	
	@Test
	void testUpdateContactPhoneNumber() {
		Contact contact = new Contact("1234567891", "Maryjobeth", "Cooperhand", "4174346472", "454 S Island Ln, Pensacola, FL");
		contactList.addContact(contact);
		
		contactList.updateContactPhoneNumber("1234567891", "4173568976");
		
		Contact updatedContact = contactList.getContact("1234567891");
		
		assertEquals("4173568976", updatedContact.getPhoneNumber());
	}
	
	@Test
	void testUpdateContactPhoneNumberNonExistingContact() {
		assertThrows(IllegalArgumentException.class, () -> contactList.updateContactPhoneNumber("noID", "4173568976"));
	}
	
	@Test
	void testUpdateContactAddress() {
		Contact contact = new Contact("1234567891", "Maryjobeth", "Cooperhand", "4174346472", "454 S Island Ln, Pensacola, FL");
		contactList.addContact(contact);
		
		contactList.updateContactAddress("1234567891", "324 N Rock St, Pensacola, FL");
		
		Contact updatedContact = contactList.getContact("1234567891");
		
		assertEquals("324 N Rock St, Pensacola, FL", updatedContact.getAddress());
	}
	
	@Test
	void testUpdateContactAddressNonExistingContact() {
		assertThrows(IllegalArgumentException.class, () -> contactList.updateContactAddress("noID", "324 N Rock St, Pensacola, FL"));
	}
}
