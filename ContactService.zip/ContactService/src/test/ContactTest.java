package test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.BeforeEach;

import ContactService.Contact;

class ContactTest {
	
	private Contact contact;
	
	@BeforeEach
	public void setUp() {
		contact = new Contact("1234567891", "Maryjobeth", "Cooperhand", "4174346472", "454 S Island Ln, Pensacola, FL");
	}
	

	@Test
	void testContactConstructorAndGetters() {
		assertTrue(contact.getContactId().equals("1234567891"));
		assertTrue(contact.getFirstName().equals("Maryjobeth"));
		assertTrue(contact.getLastName().equals("Cooperhand"));
		assertTrue(contact.getPhoneNumber().equals("4174346472"));
		assertTrue(contact.getAddress().equals("454 S Island Ln, Pensacola, FL"));	
	}
	
	@Test
	void testSetContactIdAlreadyInitializedThrowsException() {
		assertThrows(IllegalStateException.class, () -> contact.setContactId("newId"));
	}
	
	@Test
	void testSetContactIdNullThrowsException() {
		assertThrows(IllegalArgumentException.class, () -> contact = new Contact(null, "Maryjobeth", "Cooperhand", "4174346472", "454 S Island Ln, Pensacola, FL"));
	}
	
	@Test
	void testSetContactIdTooLongThrowsException() {
		assertThrows(IllegalArgumentException.class, () -> contact = new Contact("12345678912", "Maryjobeth", "Cooperhand", "4174346472", "454 S Island Ln, Pensacola, FL"));
	}
	
	@Test
	void testSetFirstNameNullThrowsException() {
		assertThrows(IllegalArgumentException.class, () -> contact.setFirstName(null));
	}
	
	@Test
	void testSetFirstNameTooLongThrowsException() {
		assertThrows(IllegalArgumentException.class, () -> contact.setFirstName("Maryjoebeth"));
	}
	
	@Test
	void testSetLastNameNullThrowsException() {
		assertThrows(IllegalArgumentException.class, () -> contact.setLastName(null));
	}
	
	@Test
	void testSetLastNameTooLongThrowsException() {
		assertThrows(IllegalArgumentException.class, () -> contact.setLastName("Coooperhand"));
	}
	
	@Test
	void testSetPhoneNumberNullThrowsException() {
		assertThrows(IllegalArgumentException.class, () -> contact.setPhoneNumber(null));
	}
	
	@Test
	void testSetPhoneNumberTooSmallThrowsException() {
		assertThrows(IllegalArgumentException.class, () -> contact.setPhoneNumber("417434647"));
	}
	
	@Test
	void testSetPhoneNumberTooBigThrowsException() {
		assertThrows(IllegalArgumentException.class, () -> contact.setPhoneNumber("41743464722"));
	}
	
	@Test
	void testSetPhoneNumberNonNumericThrowsException() {
		assertThrows(IllegalArgumentException.class, () -> contact.setPhoneNumber("417434647a"));
	}
	
	@Test
	void testSetAddressNullThrowsException() {
		assertThrows(IllegalArgumentException.class, () -> contact.setAddress(null));
	}
	
	@Test
	void testSetAddressTooLongThrowsException() {
		assertThrows(IllegalArgumentException.class, () -> contact.setAddress("4524 S Island Ln, Pensacola, FL"));
	}

}
